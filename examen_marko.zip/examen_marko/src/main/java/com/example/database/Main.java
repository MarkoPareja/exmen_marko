package com.example.database;

import com.example.database.models.Book;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        String jdbcURL = "jdbc:mysql://172.17.0.2:33060/libros";
        String jdbcUsername = "root";
        String jdbcPassword = "estudiar";

        try {
            DatabaseManager dbManager = new DatabaseManager(jdbcURL, jdbcUsername, jdbcPassword);
            dbManager.connect();

            // Crear un nou llibre
            Book newBook = new Book(0, "Geronimo Stilton", "F. Scott Fitzgerald", "Aventura");
            dbManager.addBook(newBook);

            // Recuperar llibre
            Book retrievedBook = dbManager.getBook(1);
            System.out.println(retrievedBook);

            // Actualitzar llibre
            retrievedBook.setGenre("Horror");
            dbManager.updateBook(retrievedBook);

            // Eliminar llibre
            dbManager.deleteBook(1);

            dbManager.disconnect();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
